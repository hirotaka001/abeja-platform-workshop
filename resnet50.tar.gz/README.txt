This sample is created based on the code below.
https://github.com/fchollet/deep-learning-models
