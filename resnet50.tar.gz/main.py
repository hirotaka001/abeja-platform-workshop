# https://github.com/fchollet/deep-learning-models

import numpy as np
from resnet50 import ResNet50
from keras.preprocessing import image
from imagenet_utils import preprocess_input, decode_predictions
from PIL import Image

model = ResNet50(weights='imagenet')


def process_image(img):
    img = Image.fromarray(img)  # workaround, preprocess might should be done in converter
    target_size = (224, 224)
    if img.mode != 'RGB':
        img = img.convert('RGB')
    hw_tuple = (target_size[1], target_size[0])
    if img.size != hw_tuple:
        img = img.resize(hw_tuple)

    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)

    preds = model.predict(x)
    result = [{'label': _[1], 'probability': float(_[2]), 'id': _[0]} for _ in decode_predictions(preds)[0]]
    return result


def handler(iter, context):
    for img in iter:
        yield process_image(img)
