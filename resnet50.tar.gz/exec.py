import numpy as np
import json
from PIL import Image

from main import process_image



if __name__ == '__main__':
    img = Image.open('sample.jpg')
    img = np.asarray(img)
    print(json.dumps(process_image(img)))
